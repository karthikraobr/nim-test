Version 0.14.2 released
=======================

.. container:: metadata

  Posted by Andreas Rumpf on 09/06/2016

Version 0.14.2 is just a bugfix release that fixes the most pressing
regressions. In particular, the ``tar.xz`` now supports documentation
generation, and the Windows installers bundle the latest stable nimble
release.

The news about the 0.14.0 release are still relevant, so check them out
`here <http://nim-lang.org/news/2016_06_07_version_0_14_0_released.html>`_.
