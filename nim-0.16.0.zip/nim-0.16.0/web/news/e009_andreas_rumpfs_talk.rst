2014-01-15 Andreas Rumpf's talk on Nimrod at Strange Loop 2013 is now online
============================================================================

.. container:: metadata

  Posted by Dominik Picheta on 12/01/2014

Andreas Rumpf presented *Nimrod: A New Approach to Metaprogramming* at
`Strange Loop 2013<https://thestrangeloop.com/sessions/nimrod-a-new-approach-to-meta-programming>`_.
The `video and slides<http://www.infoq.com/presentations/nimrod>`_
of the talk are now available.
