Nim in Action is now available!
===============================

.. container:: metadata

  Posted by Dominik Picheta on 27/01/2016

.. raw::html

  <a href="https://manning.com/books/nim-in-action?a_aid=niminaction&a_bid=78a27e81">
    <img src="../assets/niminaction/banner.jpg" alt="New in Manning Early Access Program: Nim in Action!" width="682"/>
  </a>

We are proud to announce that *Nim in Action*, a book about the Nim programming
language, is now available!

The book is available at this URL:
`https://www.manning.com/books/nim-in-action <https://manning.com/books/nim-in-action?a_aid=niminaction&a_bid=78a27e81>`_

The first three chapters are available for download
as an eBook through Manning's Early Access program. You can download a free
sample of the book containing the first chapter as well!

*Nim in Action* is currently being written and is expected to be completed by
Summer 2016. If you purchase the eBook you will start receiving new chapters
as they become available. You can also purchase the printed book together with
the eBook for a slightly higher price.

If you do read the book, even if it's just the first chapter, then please share
any comments, suggestions and questions on the
`Nim forum <http://forum.nim-lang.org/t/1978>`_ or in
Manning's own `Author Online forum! <https://forums.manning.com/forums/nim-in-action>`_
