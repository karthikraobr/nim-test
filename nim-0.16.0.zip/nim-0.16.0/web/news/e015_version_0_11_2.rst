Version 0.11.2 released
==================================

.. container:: metadata

  Posted by Andreas Rumpf on 04/05/2015

This is just a bugfix release that fixes the most pressing regressions we
introduced with version 0.11.0. The way types are computed was
changed significantly causing all sort of problems. Sorry for the
inconvenience; we grew overconfident our large test suite would prevent these
things.
