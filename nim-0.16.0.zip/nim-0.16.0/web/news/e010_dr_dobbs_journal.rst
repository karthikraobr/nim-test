Nimrod Featured in Dr. Dobb's Journal
=====================================

.. container:: metadata

  Posted by Dominik Picheta on 11/02/2014

Nimrod has been `featured<http://www.drdobbs.com/open-source/nimrod-a-new-systems-programming-languag/240165321>`_
as the cover story in the February 2014 issue of Dr. Dobb's Journal.
