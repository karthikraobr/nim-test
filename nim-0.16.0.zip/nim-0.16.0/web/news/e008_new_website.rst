New website design!
===================

.. container:: metadata

  Posted by Andreas Rumpf on 09/12/2014

A brand new website including an improved forum is now live.
All thanks go to Philip Witte and
Dominik Picheta, Philip Witte for the design of the website (together with
the logo) as well as the HTML and CSS code for his template, and Dominik Picheta
for integrating Philip's design with Nim's forum. We're sure you will
agree that Philip's design is beautiful.
