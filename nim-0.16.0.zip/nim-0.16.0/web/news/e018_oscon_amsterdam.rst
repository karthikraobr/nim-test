Andreas Rumpf's talk at OSCON Amsterdam
==================================================

.. container:: metadata

  Posted by Dominik Picheta on 18/01/2016

In case you have missed it, here is Andreas' Nim: An Overview talk at
OSCON Amsterdam.

.. raw:: html

  <iframe width="560" height="315" src="https://www.youtube.com/embed/4rJEBs_Nnaw" frameborder="0" allowfullscreen></iframe>
