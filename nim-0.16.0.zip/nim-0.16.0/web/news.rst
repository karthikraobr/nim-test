====
News
====

`2017-01-08 Nim Version 0.16.0 released <news/e029_version_0_16_0.html>`_
===================================

`2016-11-20 Nim in Action is going into production! <news/e030_nim_in_action_in_production.html>`_
===================================

`2016-10-23 Nim Version 0.15.2 released <news/e028_version_0_15_2.html>`_
===================================

`2016-09-30 Nim Version 0.15.0 released <news/e027_version_0_15_0.html>`_
===================================

`2016-09-03 Nim Community Survey results <news/e026_survey_results.html>`_
===================================

`2016-08-06 BountySource Update: The Road to v1.0 <news/e025_bountysource_update.html>`_
===================================

`2016-06-23 Launching the 2016 Nim community survey <news/e024_survey.html>`_
===================================

`2016-06-11 Version 0.14.2 released <news/e023_version_0_14_2.html>`_
===================================

`2016-06-07 Version 0.14.0 released <news/e022_version_0_14_0.html>`_
===================================

`2016-06-04 Meet our BountySource sponsors <news/e021_meet_sponsors.html>`_
===================================

`2016-01-27 Nim in Action is now available! <news/e020_nim_in_action.html>`_
==================================

`2016-01-18 Version 0.13.0 released <news/e019_version_0_13_0.html>`_
==================================

`2016-01-18 Andreas Rumpf's talk at OSCON Amsterdam <news/e018_oscon_amsterdam.html>`_
==================================================

`2015-10-27 Version 0.12.0 released <news/e017_version_0_12_0.html>`_
==================================

`2015-10-16 First Nim conference <news/e016_nim_conf1.html>`_
===============================

`2015-05-04 Version 0.11.2 released <news/e015_version_0_11_2.html>`_
==================================

`2015-04-30 Version 0.11.0 released <news/e014_version_0_11_0.html>`_
==================================

`2014-12-29 Version 0.10.2 released <news/e013_version_0_10_2.html>`_
==================================


`2014-10-19 Version 0.9.6 released <news/e012_version_0_9_6.html>`_
=================================


`2014-04-21 Version 0.9.4 released <news/e011_version_0_9_4.html>`_
=================================


`2014-02-11 Nimrod Featured in Dr. Dobb's Journal <news/e010_dr_dobbs_journal.html>`_
================================================


`2014-01-15 Andreas Rumpf's talk on Nimrod at Strange Loop 2013 is now online <news/e009_andreas_rumpfs_talk.html>`_
============================================================================


`2013-05-20 New website design! <news/e008_new_website.html>`_
==============================



`2013-05-20 Version 0.9.2 released <news/e007_version_0_9_2.html>`_
=================================



`2012-09-23 Version 0.9.0 released <news/e006_version_0_9_0.html>`_
=================================



`2012-02-09 Version 0.8.14 released <news/e005_version_0_8_14.html>`_
==================================



`2011-07-10 Version 0.8.12 released <news/e004_version_0_8_12.html>`_
==================================


`2010-10-20 Version 0.8.10 released <news/e003_version_0_8_10.html>`_
==================================



`2010-03-14 Version 0.8.8 released <news/e002_version_0_8_8.html>`_
=================================


`2009-12-21 Version 0.8.6 released <news/e001_version_0_8_6.html>`_
=================================


2009-10-21 Version 0.8.2 released
=================================


2009-09-12 Version 0.8.0 released
=================================


2009-06-08 Version 0.7.10 released
==================================


2009-05-08 Version 0.7.8 released
=================================


2009-04-22 Version 0.7.6 released
=================================


2008-11-16 Version 0.7.0 released
=================================


2008-08-22 Version 0.6.0 released
=================================

Nimrod version 0.6.0 has been released!
**This is the first version of the compiler that is able to compile itself!**
