In this directory you will find several examples for how to use the Nimrod
library.

Copyright (c) 2004-2012 Andreas Rumpf.
All rights reserved.
