This example demonstrates how to use Nim with Lazarus. The GUI is generated
with Lazarus, while the "backend" is written in Nim. To compile the example,
use this command:

  nim c --app:gui --no_main --no_linking backend.nim

Open the ``nimlaz.lpi`` file in Lazarus and run the program.

