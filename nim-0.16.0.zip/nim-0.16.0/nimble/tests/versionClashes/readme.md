Tests to ensure that the following errors are correct.

```
Cannot satisfy dependency on gtk2 1.0 and gtk2 1.1
```